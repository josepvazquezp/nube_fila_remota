# fila_remota
## Prerequisitos:
npm install 
crear el doc .env con la URL del Mongo proporcionado en el example.env y usuario y contraseña correctos.

## Para correr la api:
npm start

## Nota: Para acceder a la documentación se utiliza la ruta localhost:3000/swagger
